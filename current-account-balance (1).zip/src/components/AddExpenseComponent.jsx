import { useState } from 'react';
import './component.css';
import { Alert, InputGroup, Form, FormControl, FloatingLabel, Button } from 'react-bootstrap';

export default function AddExpenseComponent (props) {
    let [showAlert, setAlert] = useState(false);
    let [totalAmt, setAmount] = useState('');
    let [category, setCategory] = useState('');
    let [comment, setComment] = useState('');

    const addExpense = () => {
        if(showAlert) setAlert(false);
        let totalAmount = props.getTotalAmt();
        if(Number(totalAmt) > 0) {
            if(totalAmount + Number(totalAmt) > props.currentBalance) {
                console.log('Expense crossing current balance')
                setAlert(true);
                return false;
            } else {
                let expenseObj = [...props.totalExpenses];
                expenseObj.push({
                    totalAmt: Number(totalAmt),
                    category,
                    comment
                });
                props.setExpenses(expenseObj);
                props.hideAddExpense();
            }
        } else {
            return false;
        }
    }

    return (
        <>
            {showAlert && <Alert variant="warning">Expense crossing current balance</Alert>}
            <div className='col-lg'>
                <InputGroup className="mb-3">
                    <InputGroup.Text>$</InputGroup.Text>
                    <FormControl aria-label="Amount (to the nearest dollar)" value={totalAmt} onChange={e => setAmount(e.target.value)} />
                    <InputGroup.Text>.00</InputGroup.Text>
                </InputGroup>
                <Form.Select size="lg" value={category} onChange={e => setCategory(e.target.value)}>
                    <option value="">Please select category</option>
                    <option value="Housing">Housing</option>
                    <option value="Food">Food</option>
                    <option value="Insurance">Insurance</option>
                    <option value="Transportation">Transportation</option>
                    <option value="Taxes">Taxes</option>
                </Form.Select>
                <FloatingLabel controlId="floatingTextarea2" label="Comments">
                    <Form.Control value={comment} onChange={e => setComment(e.target.value)}
                    as="textarea"
                    placeholder="Leave a comment here"
                    style={{ height: '100px' }}
                    />
                </FloatingLabel>
                <Button variant="primary" onClick={addExpense}>Add</Button>
                <Button variant="primary" onClick={() => props.hideAddExpense()}>Close</Button>
            </div>
        </>
    )
}