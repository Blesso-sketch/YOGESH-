import { Card } from "react-bootstrap";

export default function CardComponent (props) {
    return (
        <Card>
            <Card.Header>{props.category}</Card.Header>
            <Card.Body>
                <Card.Title>Total Amount: <br/>${props.totalAmt}</Card.Title>
                <Card.Text>
                <i>&#8220;{props.comment}&#8221;</i>
                </Card.Text>
            </Card.Body>
        </Card>
    )
}