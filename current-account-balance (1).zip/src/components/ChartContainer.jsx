import { Chart, ChartLegend, ChartSeries, ChartSeriesItem, ChartTitle, ChartSeriesLabels } from '@progress/kendo-react-charts';
import 'hammerjs';

const labelContent = (e) => (e.category);
function createChartSeries (arr) {
    let res = [
        {
            category: 'Housing',
            totalAmt: 0
        },
        {
            category: 'Food',
            totalAmt: 0
        },
        {
            category: 'Transportation',
            totalAmt: 0
        },
        {
            category: 'Insurance',
            totalAmt: 0
        },
        {
            category: 'Taxes',
            totalAmt: 0
        }
    ];
    let idx = -1;
    for(let i=0; i<arr.length; i++) {
        switch(arr[i].category) {
            case 'Housing':
                idx = res.findIndex(item => item.category === 'Housing');
                res[idx].totalAmt += arr[i].totalAmt;
                break;
            case 'Food':
                idx = res.findIndex(item => item.category === 'Food');
                res[idx].totalAmt += arr[i].totalAmt;
                break;
            case 'Transportation': 
                idx = res.findIndex(item => item.category === 'Transportation');
                res[idx].totalAmt += arr[i].totalAmt;
                break;
            case 'Insurance': 
                idx = res.findIndex(item => item.category === 'Insurance');
                res[idx].totalAmt += arr[i].totalAmt;
                break;
            case 'Taxes': 
                idx = res.findIndex(item => item.category === 'Taxes');
                res[idx].totalAmt += arr[i].totalAmt;
                break;
            default:
                break;
        }
    }

    return res;
}

const ChartContainer = (props) => {
    let series = createChartSeries(props.expenseDetails);
    return (
    <Chart>
        <ChartTitle text='World Population by Broad Age Groups' />
        <ChartLegend position="bottom" visible={false}/>
        <ChartSeries>
            <ChartSeriesItem type="donut" data={series} field="totalAmt" categoryField="category">
                <ChartSeriesLabels
                color="#fff"
                background="none"
                content={labelContent}
                />
            </ChartSeriesItem>
        </ChartSeries>
    </Chart>
    );
}

export default ChartContainer;