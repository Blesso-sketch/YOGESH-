import '@progress/kendo-theme-default/dist/all.css';
import './App.css';
import { useState } from 'react';
import AddExpenseComponent from './components/AddExpenseComponent';
import CardComponent from './components/CardComponent';
import { Button } from 'react-bootstrap';
import ChartContainer from './components/ChartContainer';

function App() {
  const [currentBalance , setCurrentBalance] = useState(1000);
  const [expenses, setExpenses] = useState([]);
  const [showAddBtn, toggeAddBtn] = useState(true);

  const calculateTotal = () => {
    return expenses.length && expenses.reduce((sum, item) => sum += Number(item.totalAmt), 0);
  }
  
  const hideAddExpense = () => {
    toggeAddBtn(true);
  }

  const showAddExpense = () => {
    toggeAddBtn(false);
  }

  return (
    <div className="App">
      <section>
        <header>
          <div className="current-balance">Current Balance: ${currentBalance}</div>
        </header>
        <main className="App-header">
          { showAddBtn &&
            <div className="d-grid gap-2">
              <Button onClick={showAddExpense} variant="primary" size="lg">+ Add new expense</Button>
            </div>
          }
          { !showAddBtn && <AddExpenseComponent hideAddExpense={hideAddExpense} currentBalance={currentBalance} setExpenses={setExpenses} totalExpenses={expenses} getTotalAmt={calculateTotal}/>}
        </main>
        <section className="expense-tracker">
          {showAddBtn && calculateTotal() > 0 ? 
            expenses.length && expenses.map((item, index) => <CardComponent key={index} {...item}/>)
          : ''}
        </section>
      </section>
      <section>
        <ChartContainer expenseDetails={expenses} />
      </section>
      
    </div>
  );
}

export default App;
